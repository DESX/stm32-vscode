/**
  @page Demo STM32CubeL4_Demo_STM32L432KC_Nucleo-V1.0.0.hex
 
  @verbatim
  ******************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of NUCLEO-L432KC RevC Demo
  ******************************************************************************
  *
  * Copyright (c) 2017 STMicroelectronics. All rights reserved.
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                       opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  @endverbatim

@par Demo Description

Demonstration of firmware based on STM32Cube. This example provides firmware to
to help you to discover STM32 Cortex-M devices that are plugged onto an your
STM32NUCLEO_32 board.

At the beginning of the main program the HAL_Init() function is called to reset 
all the peripherals, initialize the Flash interface and the systick.
Then the SystemClock_Config() function is used to configure the system clock
(SYSCLK) to run at 2 MHz.
 
 
Below you find the sequence to discover the demonstration :

  This demo needs a Gravitech 4 digits 7 segment nano shield.
  You will find it here : http://www.gravitech.us/7sediforarna.html
  Plug the STM32NUCLEO_32 on top of this shield.
  The demo changes the power mode every 10 seconds and updates the display every second.
  The last digit corresponds to the time.
  The first digit corresponds to the power mode as is described below :
    100X = RUN Mode
    200X = SLEEP Mode
    300X = STOP1 Mode
    400X = STOP2 Mode
    500X = STANDBY Mode
    600X = LPRUN Mode
    700X = LPSLEEP Mode
  For details about the low power modes, please look at the stm32l4xx reference manual.


@par Hardware and Software environment

  - This example runs on STM32L432xx devices.
  - This demo has been tested with NUCLEO-L432KC RevC board and can be
    easily tailored to any other supported device and development board.
  - Gravitech 4 digits 7 segment nano shield is connected on Arduino nano connectors.

@par How to use 

 + Using "in-system programming tool" such as ST-Link Utility
    - Connect the NUCLEO-L432KC board to a PC with a 'USB Type-A to Micro-B'
      cable through USB connector CN1 to power the board.
    - Use "STM32CubeL4_Demo_STM32L432KC_Nucleo-V1.0.0.hex" binary with your preferred 
      in-system programming tool to reprogram the demonstration firmware via the 
      embedded ST-LINK/V2-1 configured for in-system programming
      (ex. STM32 ST-LINK Utility, available for download from www.st.com).
 
 * <h3><center>&copy; COPYRIGHT STMicroelectronics</center></h3>
 */
